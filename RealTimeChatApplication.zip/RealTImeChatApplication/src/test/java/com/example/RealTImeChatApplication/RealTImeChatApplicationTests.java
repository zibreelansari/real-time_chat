package com.example.RealTImeChatApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RealTImeChatApplicationTests {

	@Test
	void contextLoads() {
	}

}
