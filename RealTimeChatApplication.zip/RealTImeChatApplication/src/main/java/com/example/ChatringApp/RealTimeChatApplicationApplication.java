package com.example.ChatringApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RealTimeChatApplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(RealTimeChatApplicationApplication.class, args);
	}

}
